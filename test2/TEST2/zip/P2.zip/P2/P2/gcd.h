#pragma once

#ifndef GCD_H
#define GCD_H

extern void Input_Integer();

extern int gcd(int x, int y);

extern int gcd2(int x, int y);

extern int min(int a, int b);

#endif

