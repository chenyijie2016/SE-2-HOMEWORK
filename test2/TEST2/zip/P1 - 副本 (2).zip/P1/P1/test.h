#ifndef TEST_H
#define  TEST_H

void StartTest();

void StartSingleTest();

#endif
